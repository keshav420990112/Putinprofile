export const data = {
  technicalSkills: [
    { name: "JavaScript", percentage: 90 },
    { name: "React", percentage: 85 },
    { name: "Node.js", percentage: 80 },
    { name: "Python", percentage: 75 },
  ],
  
  professionalSkills: [
    { name: "Problem Solving", percentage: 95 },
    { name: "Team Leadership", percentage: 85 },
    { name: "Communication", percentage: 90 },
    { name: "Project Management", percentage: 80 },
  ],
  
  projects: [
    {
      title: "Analytics Dashboard",
      description: "A real-time data visualization dashboard built with React and D3.js. Features responsive charts and customizable widgets.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      technologies: ["React", "D3.js", "Firebase"],
      demoLink: "#",
      codeLink: "https://github.com",
    },
    {
      title: "Mobile Task Manager",
      description: "A productivity app built with React Native. Features task management, reminders, and collaboration tools.",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      technologies: ["React Native", "Redux", "Node.js"],
      demoLink: "#",
      codeLink: "https://github.com",
    },
    {
      title: "E-commerce Platform",
      description: "A full-featured online shopping platform with payment processing, inventory management, and analytics.",
      image: "https://images.unsplash.com/photo-1574634534894-89d7576c8259?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      technologies: ["Next.js", "MongoDB", "Stripe"],
      demoLink: "#",
      codeLink: "https://github.com",
    },
  ],
};
