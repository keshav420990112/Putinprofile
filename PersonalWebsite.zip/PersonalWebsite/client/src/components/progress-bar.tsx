import { cn } from "@/lib/utils";
import { useRef, useEffect, useState } from "react";
import { useInView } from "framer-motion";

interface ProgressBarProps {
  percentage: number;
  color?: "primary" | "secondary";
}

export default function ProgressBar({ percentage, color = "primary" }: ProgressBarProps) {
  const [width, setWidth] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.5 });
  
  useEffect(() => {
    if (isInView) {
      setWidth(percentage);
    }
  }, [isInView, percentage]);
  
  return (
    <div ref={ref} className="progress-bar">
      <div 
        className={cn(
          "progress-fill", 
          color === "primary" ? "bg-primary" : "bg-secondary"
        )} 
        style={{ width: `${width}%` }}
      ></div>
    </div>
  );
}
