import { Button } from "@/components/ui/button";
import SectionFade from "@/components/section-fade";
import { 
  BriefcaseIcon, 
  GraduationCapIcon,
  MapPinIcon,
  GlobeIcon 
} from "lucide-react";

export default function AboutSection() {
  const infoItems = [
    {
      icon: <GraduationCapIcon className="text-primary" />,
      title: "Education",
      detail: "CS Degree, Stanford University"
    },
    {
      icon: <BriefcaseIcon className="text-primary" />,
      title: "Experience",
      detail: "5+ Years in Software Development"
    },
    {
      icon: <MapPinIcon className="text-primary" />,
      title: "Location",
      detail: "San Francisco, CA"
    },
    {
      icon: <GlobeIcon className="text-primary" />,
      title: "Languages",
      detail: "English, Spanish"
    }
  ];
  
  return (
    <section id="about" className="py-20 bg-light">
      <SectionFade>
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-2/5">
              <img 
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800" 
                alt="John Doe working at desk" 
                className="rounded-lg shadow-lg w-full h-auto object-cover"
              />
            </div>
            <div className="md:w-3/5">
              <h2 className="text-3xl font-heading font-bold mb-6 relative inline-block">
                About Me
                <span className="absolute bottom-0 left-0 w-1/2 h-1 bg-primary"></span>
              </h2>
              <p className="text-lg text-dark/80 mb-4">
                I'm a passionate software developer based in San Francisco with over 5 years of experience creating 
                modern web applications and digital experiences that users love.
              </p>
              <p className="text-lg text-dark/80 mb-6">
                My journey in technology began when I built my first website at 14. Since then, I've dedicated myself to 
                mastering the latest technologies and best practices in software development.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {infoItems.map((item, index) => (
                  <div key={index} className="flex items-center">
                    <div className="mr-3 w-5 h-5">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-medium">{item.title}</h3>
                      <p className="text-dark/70">{item.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button
                size="lg"
                className="px-8 rounded-full shadow-md"
                asChild
              >
                <a href="#contact">Download Resume</a>
              </Button>
            </div>
          </div>
        </div>
      </SectionFade>
    </section>
  );
}
