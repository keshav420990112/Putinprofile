import SectionFade from "@/components/section-fade";
import ProgressBar from "@/components/progress-bar";
import { 
  FaHtml5, 
  FaCss3Alt, 
  FaJs, 
  FaReact,
  FaNodeJs,
  FaPython,
  FaGitAlt,
  FaDocker
} from "react-icons/fa";
import { data } from "@/lib/data";

export default function SkillsSection() {
  const { technicalSkills, professionalSkills } = data;
  
  const SkillIcon = ({ icon: Icon, name }: { icon: React.ElementType, name: string }) => (
    <div className="flex flex-col items-center p-6 rounded-lg bg-light">
      <Icon className="text-4xl text-primary mb-3" />
      <span className="font-medium">{name}</span>
    </div>
  );
  
  const iconSkills = [
    { icon: FaHtml5, name: "HTML5" },
    { icon: FaCss3Alt, name: "CSS3" },
    { icon: FaJs, name: "JavaScript" },
    { icon: FaReact, name: "React" },
    { icon: FaNodeJs, name: "Node.js" },
    { icon: FaPython, name: "Python" },
    { icon: FaGitAlt, name: "Git" },
    { icon: FaDocker, name: "Docker" }
  ];
  
  return (
    <section id="skills" className="py-20">
      <SectionFade>
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-heading font-bold mb-4">My Skills</h2>
            <p className="text-lg text-dark/70 max-w-2xl mx-auto">
              I've worked with a variety of technologies and methodologies throughout my career.
              Here are some of the key skills I bring to projects.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            <div>
              <h3 className="text-xl font-heading font-medium mb-6">Technical Skills</h3>
              
              {technicalSkills.map((skill, index) => (
                <div className="mb-6" key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span>{skill.percentage}%</span>
                  </div>
                  <ProgressBar 
                    percentage={skill.percentage} 
                    color="primary" 
                  />
                </div>
              ))}
            </div>
            
            <div>
              <h3 className="text-xl font-heading font-medium mb-6">Professional Skills</h3>
              
              {professionalSkills.map((skill, index) => (
                <div className="mb-6" key={index}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span>{skill.percentage}%</span>
                  </div>
                  <ProgressBar 
                    percentage={skill.percentage} 
                    color="secondary" 
                  />
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {iconSkills.map((skill, index) => (
              <SkillIcon key={index} icon={skill.icon} name={skill.name} />
            ))}
          </div>
        </div>
      </SectionFade>
    </section>
  );
}
