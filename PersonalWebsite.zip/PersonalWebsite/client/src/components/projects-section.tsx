import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FaGithub } from "react-icons/fa";
import SectionFade from "@/components/section-fade";
import { data } from "@/lib/data";

export default function ProjectsSection() {
  const { projects } = data;
  
  return (
    <section id="projects" className="py-20 bg-light">
      <SectionFade>
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-heading font-bold mb-4">My Projects</h2>
            <p className="text-lg text-dark/70 max-w-2xl mx-auto">
              Here are some of my recent projects. Each project represents unique challenges and solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div 
                key={index}
                className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-2 group"
              >
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-heading font-bold mb-2">{project.title}</h3>
                  <p className="text-dark/70 mb-4">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech, i) => (
                      <span key={i} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between">
                    <a href={project.demoLink} className="text-primary font-medium hover:underline">
                      View Project
                    </a>
                    <a href={project.codeLink} className="text-dark/70 hover:text-primary transition-colors">
                      <FaGithub className="text-xl" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button
              variant="outline"
              size="lg"
              className="px-8 rounded-full border-2 border-primary text-primary hover:bg-primary hover:text-white"
              asChild
            >
              <a href="https://github.com">View All Projects</a>
            </Button>
          </div>
        </div>
      </SectionFade>
    </section>
  );
}
