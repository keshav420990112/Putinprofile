import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center pt-16 pb-32 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: "url('/attached_assets/image_1747652265003.png')" }}>
      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col items-center text-center">
          <motion.div
            className="flex flex-col items-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <img 
              src="/attached_assets/image_1747652388845.png" 
              alt="PUTIN Profile" 
              className="rounded-full w-44 h-44 md:w-56 md:h-56 object-cover border-4 border-primary shadow-2xl mb-6"
            />
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-heading font-bold mb-4 text-white tracking-wider bg-gradient-to-r from-blue-500 via-purple-500 to-orange-500 bg-clip-text text-transparent">PUTINxPROFILE</h1>
            
            <div className="flex space-x-4 mt-8">
              <Button
                size="lg"
                className="px-8 rounded-full shadow-md hover:shadow-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                asChild
              >
                <a href="#contact">Contact Me</a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="px-8 rounded-full border-white text-white hover:bg-white/10"
                asChild
              >
                <a href="#projects">View Projects</a>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
      <div className="absolute inset-0 bg-black/60 z-0"></div>
    </section>
  );
}
