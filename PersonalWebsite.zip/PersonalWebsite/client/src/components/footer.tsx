import { FaLinkedinIn, FaGithub, FaTwitter, FaDribbble } from "react-icons/fa";

export default function Footer() {
  const year = new Date().getFullYear();
  
  const socialLinks = [
    { icon: <FaLinkedinIn />, href: "https://linkedin.com" },
    { icon: <FaGithub />, href: "https://github.com" },
    { icon: <FaTwitter />, href: "https://twitter.com" },
    { icon: <FaDribbble />, href: "https://dribbble.com" },
  ];
  
  return (
    <footer className="bg-dark text-text-light py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a href="#home" className="text-2xl font-heading font-bold text-white">
              JD<span className="text-primary">.</span>
            </a>
            <p className="mt-2 text-gray-400 max-w-md">
              Creating modern, responsive web applications with a focus on performance and user experience.
            </p>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="flex space-x-4 mb-4">
              {socialLinks.map((link, index) => (
                <a 
                  key={index}
                  href={link.href}
                  className="text-gray-400 hover:text-primary transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {link.icon}
                </a>
              ))}
            </div>
            <p className="text-gray-500 text-sm">
              &copy; {year} John Doe. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
