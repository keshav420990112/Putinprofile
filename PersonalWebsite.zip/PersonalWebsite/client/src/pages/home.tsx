export default function Home() {
  return (
    <div className="font-sans text-white min-h-screen bg-cover bg-center bg-no-repeat" style={{ backgroundImage: "url('/assets/image_1747653047392.png')" }}>
      <div className="min-h-screen flex flex-col items-center justify-center bg-black/60 px-4">
        <div className="max-w-md w-full mx-auto flex flex-col items-center">
          {/* Profile Image */}
          <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-teal-400 mb-3">
            <img 
              src="/assets/image_1747652388845.png" 
              alt="Putin Profile" 
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Profile Name */}
          <h1 className="text-2xl font-bold text-white mb-4">PUTINxPROFILE</h1>
          
          {/* Name and Skills */}
          <div className="bg-gray-900/70 p-4 rounded-lg mb-6 w-full">
            <p className="text-center text-lg text-purple-400 font-medium mb-2">ＮＡＭＥ ：－ ＰＵＴＩＮ</p>
            <p className="text-center text-purple-300 mb-3">♫єχρєят ιη</p>
            
            <div className="grid grid-cols-1 text-sm skill-list">
              <p className="mb-1 skill-item">→ ᴄᴀʀᴅɪɴɢ</p>
              <p className="mb-1 skill-item">→ ʙᴏᴛ ᴍᴀᴋᴇʀ</p>
              <p className="mb-1 skill-item">→ ᴄᴄ ᴅᴜᴍᴘɪɴɢ</p>
              <p className="mb-1 skill-item">→ ᴄʀᴀᴄᴋɪɴɢ</p>
              <p className="mb-1 skill-item">→ ʙ!ɴ ꜰɪɴᴅɪɴɢ (ʙ!ɴɴ!ɴɢ)</p>
              <p className="mb-1 skill-item">→ ʙᴜɢ ʜᴜɴᴛɪɴɢ</p>
              <p className="mb-1 skill-item">→ ᴘʜʏᴛʜᴏɴ (60%)</p>
              <p className="mb-1 skill-item">→ ᴘʜᴘ (70%)</p>
              <p className="mb-1 skill-item">→ ᴡᴇʙꜱɪᴛᴇ ᴅᴇᴠᴇʟᴏᴘᴇʀ</p>
              <p className="mb-1 skill-item">→ ꜰᴜʟʟ ꜱᴛᴀᴄᴋ ᴅᴇᴠᴇʟᴏᴘᴇʀ (ꜰʀᴏɴᴛᴇɴᴅ, ʙᴀᴄᴋᴇɴᴅ)</p>
              <p className="mb-1 skill-item">→ ꜱᴄʀɪᴘᴛ ᴍᴀᴋᴇʀ</p>
              <p className="mb-1 skill-item">→ ᴊᴀᴠᴀ (30%)</p>
              <p className="mb-1 skill-item">→ ᴘʀɪᴄᴇ ᴛᴇᴍᴘᴇʀɪɴɢ</p>
              <p className="mb-1 skill-item">→ ʟᴏɢꜱ (40%)</p>
              <p className="mb-1 skill-item">→ ɴᴇᴛᴡᴏʀᴋɪɴɢ (60%)</p>
              <p className="mb-1 skill-item">→ ʙᴜɢ ʜᴜɴᴛɪɴɢ (40%)</p>
              <p className="mb-1 skill-item">→ ꜱᴘᴇʀᴀᴅɪɴɢ</p>
              <p className="mb-1 skill-item">→ ʀᴀᴛ ᴇXᴘᴇʀᴛ</p>
              <p className="mb-1 skill-item">→ ɢᴀɴɪɴɢ….</p>
            </div>
          </div>
          
          {/* Additional Text */}
          <a href="https://t.me/+M8WlctkCwAAyZDU1" target="_blank" rel="noopener noreferrer" className="w-full">
            <p className="bg-gray-900/70 w-full text-center py-2 rounded-lg mb-3 hover:bg-gray-800/80 transition-colors cursor-pointer">SECURE BIT SOCIETY</p>
          </a>
          <a href="https://t.me/Putinxop" target="_blank" rel="noopener noreferrer" className="w-full">
            <p className="bg-gray-900/70 w-full text-center py-2 rounded-lg mb-3 hover:bg-gray-800/80 transition-colors cursor-pointer">ABOUT PUTIN</p>
          </a>
          <a href="https://t.me/putinbbolteapunko" target="_blank" rel="noopener noreferrer" className="w-full">
            <p className="bg-gray-900/70 w-full text-center py-2 rounded-lg mb-6 hover:bg-gray-800/80 transition-colors cursor-pointer">MY TELEGRAM USERNAME</p>
          </a>
        </div>
      </div>
    </div>
  );
}
